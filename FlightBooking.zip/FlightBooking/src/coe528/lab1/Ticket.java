
package coe528.lab1;

/**
 *
 * @author Ayoub
 */
public class Ticket {
    
    private Passenger passenger;
    private Flight flight;
    private double price;
    private int number;
    private static int totalTickets = 0;
    
    public Ticket(Passenger p, Flight flight, double price) {
    
        this.passenger = p;
        this.flight = flight;
        this.price = price;
        this.number = ++Ticket.totalTickets;
        // or Ticket.totalTickets++;  this.number = Ticket.totalTickets;
        
    }
    
    public Passenger getPassenger(){
        return passenger;
    }
    
    public void setPassenger(Passenger newPassenger){
        this.passenger = newPassenger;
    }
    
    public Flight getFlight(){
        return flight;
    }
    
    public void setFlight( Flight newFlight){
        this.flight = newFlight;
    }
    
    public double getPrice(){
        return price;
    }
    
    public void setPrice(double newPrice){
        this.price = newPrice;
    }
    
    public int getNumber(){
        return number;
    }
    
    public void setNumber(int number){
        this.number = number;
    }
    
    @Override
    
    public String toString() {
    
        return "Name: " + passenger.getName() + ", Flight Number: " + flight.getFlightNumber() + ", Departing from: "+ flight.getOrigin() + ", and Arriving in: "+ flight.getDestination()+ ", Departing on: "+ flight.getDepartureTime()+ "Orignal Price: "+ flight.getOriginalPrice()+ "Price After Discount: "+ passenger.applyDiscount(flight.getOriginalPrice());        
    }
    
}
