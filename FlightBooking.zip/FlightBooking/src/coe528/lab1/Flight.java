
package coe528.lab1;

/**
 *
 * @author ayoub
 */
public class Flight {
    private int flightNumber;
    private String origin;
    private String destination;
    private String departureTime;
    private int capacity;
    private int numberOfSeatsLeft;
    private double originalPrice;
    
    public Flight(int flightNumber, String origin, String destination, String departureTime, int capacity, double originalPrice){
     
    this.flightNumber = flightNumber;
     this.origin = origin;
     this.destination = destination;
     this.departureTime = departureTime;
     this.capacity = capacity;
     this.numberOfSeatsLeft = capacity;
     this.originalPrice = originalPrice;
    
    if(origin.equals(destination)){
        throw new IllegalArgumentException("Error: Origin and destination can't be the same");
    }
}
    
    public boolean bookASeat(){
        if (numberOfSeatsLeft > 0){
            numberOfSeatsLeft--;
            return true;
        } else
            return false;
    }
    

    public int getFlightNumber(){
        return flightNumber;
    }
    
    public void setFlightNumber(int newFlightNumber ){
        this.flightNumber= newFlightNumber;
    }
    
    public String getOrigin(){
        return origin;
    }
    
    public void setOrigin(String newOrigin){
        this.origin=newOrigin;
    }
    
    public String getDestination(){
        return destination;
    }
    
    public void setDestination(String newDestination){
        this.destination=newDestination;
    }
    
    public String getDepartureTime(){
        return departureTime;
    }
    
    public void setDepartureTime(String newDepartureTime){
        this.departureTime=newDepartureTime;
    }
    
    public int getCapacity(){
        return capacity;
    }
    
    public void setCapacity(int newCapacity){
        this.capacity=newCapacity;
    }
    
    public int getNumberOfSeatsLeft(){
        return numberOfSeatsLeft;
    }
    
    public void setNumberOfSeatsLeft(int newNumberOfSeatsLeft){
        this.numberOfSeatsLeft=newNumberOfSeatsLeft;
    }
    
    public double getOriginalPrice(){
        return originalPrice;
    }
    
    public void setOriginalPrice(double newOriginalPrice){
        this.originalPrice=newOriginalPrice;
    }
    @Override
    public String toString(){
        return "Flight Number: " + getFlightNumber()+ ", " + getOrigin() + " to " + getDestination() + ", " + getDepartureTime() + ", Original Price: $" +getOriginalPrice() +"\n";
    }
    
}
